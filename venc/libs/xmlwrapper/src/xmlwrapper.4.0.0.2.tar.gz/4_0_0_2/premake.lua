MODEL = "xmlwrapper"

addoption("shared", "Try to build shared library")
addoption("debug", "Output debug message")

project.name = MODEL
project.libdir = "lib"
project.bindir = "app"
project.configs = { "Release" }

-- Libraries
	package = newpackage()
	package.name = string.upper(MODEL) .. "Lib"
	package.kind = "lib"
	package.language = "c"
	package.target = MODEL
	-- Options
	if (options["host"]) and (options["host"] == "arm-linux") then
		table.insert(package.buildoptions, "-march=armv4t")
		table.insert(package.defines, "_ARM_LINUX")
	else
		table.insert(package.buildoptions, "-Wdeclaration-after-statement")
	end
	if (options["debug"]) then
		table.insert(package.defines, "_DEBUG")
	end
	if (options["shared"]) then
		package.kind = "dll"
		szLibHdr = "src/" .. package.target .. ".h"
		for line in io.lines(szLibHdr) do
			if string.find(line, "^#define[%a%A]+MAKEFOURCC[%a%A]+") then
				_, _, a, b, c, d = string.find(line, "#[%l%u%s_(]+(%d+)[%p%s]+(%d+)[%p%s]+(%d+)[%p%s]+(%d+)")
				package.targetextension = "so." .. a .. "." .. b .. "." .. c .. "." .. d
				break;
			end
		end
		table.insert(package.linkoptions, "-Wl,-soname,lib" .. MODEL .. ".so." .. a)
	end
	-- Set Objects Path
	package.objdir = "./obj"
	-- Build Options
	table.insert(package.buildoptions, "-Wall")
	-- Include Paths
	package.includepaths = {
		"./include"
	}
	-- Files
	package.files = {
		matchrecursive("src/*.h", "src/*.c")
	}
-- Applications
	package = newpackage()
	package.name = string.upper(MODEL) .. "App"
	package.kind = "exe"
	package.language = "c"
	package.target = MODEL .. "_app"
	-- Options
	if (options["host"]) and (options["host"] == "arm-linux") then
		table.insert(package.buildoptions, "-march=armv4t")
	end
	if (options["debug"]) then
		table.insert(package.defines, "_DEBUG")
	end
	-- Set Objects Path
	package.objdir = "./app"
	-- Build Options
	table.insert(package.buildoptions, "-Wall")
	-- Include Paths
	package.includepaths = {
		"./include", "./src"
	}
	-- Links
	package.links = {
		MODEL, "expat"
	}
	-- Files
	package.files = {
		matchrecursive("app/*.h", "app/*.c")
	}

