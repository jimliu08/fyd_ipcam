/*
 *******************************************************************************
 * $Header: $
 *
 *  Copyright (c) 2000-2006 VN Inc. All rights reserved.
 *
 *  +-----------------------------------------------------------------+
 *  | THIS SOFTWARE IS FURNISHED UNDER A LICENSE AND MAY ONLY BE USED |
 *  | AND COPIED IN ACCORDANCE WITH THE TERMS AND CONDITIONS OF SUCH  |
 *  | A LICENSE AND WITH THE INCLUSION OF THE THIS COPY RIGHT NOTICE. |
 *  | THIS SOFTWARE OR ANY OTHER COPIES OF THIS SOFTWARE MAY NOT BE   |
 *  | PROVIDED OR OTHERWISE MADE AVAILABLE TO ANY OTHER PERSON. THE   |
 *  | OWNERSHIP AND TITLE OF THIS SOFTWARE IS NOT TRANSFERRED.        |
 *  |                                                                 |
 *  | THE INFORMATION IN THIS SOFTWARE IS SUBJECT TO CHANGE WITHOUT   |
 *  | ANY PRIOR NOTICE AND SHOULD NOT BE CONSTRUED AS A COMMITMENT BY |
 *  | VN INC.                                                    |
 *  +-----------------------------------------------------------------+
 *
 * $History: $
 * 
 */

/*!
 *******************************************************************************
 * Copyright 2000-2006 VN, Inc. All rights reserved.
 *
 * \file
 * XmlWrapper_Options.h
 *
 * \brief
 * header file of XmlWrapper_Options.c
 *
 * \date
 * 2006/12/01
 *
 * \author
 * Ming-Jing Tsai
 *
 *
 *******************************************************************************
 */

#ifndef _XMLWRAPPER_OPTIONS_H_
#define _XMLWRAPPER_OPTIONS_H_

#include "xmlwrapper.h"

#if 0
// --------------------- function brief ----------------------------------------
SCODE XmlWrapper_SetXMLTreeNodeHdl(TXMLElem *ptxeDocRoot, const char *pcPath, StartElemHandler pfStartHdl, XML_CharacterDataHandler pfChDataHdl, XML_EndElementHandler pfEndHdl, TXmlWrapperNamespaceMap *ptNSMap);
void XmlWrapper_ClearTree(TXMLElem *ptxeRoot);
#endif

/*!
******************************************************************************
* \brief
* set startElem and ChData handler
*
* \param ptxeDocRoot
* \a (i) root of xmltree
*
* \param pcPath
* \a (i) tree path to set handler
* 
* \param  pfStartHdl
* \a (i) call back function of startElem handler
*
* \param  pfChDataHdl
* \a (i) call back function of ChData handler
*
* \param  pfEndHdl
* \a (i) call back function of endElem handler
*
* \param  ptNSMap
* \a (i) pointer of namespace map
*
* \retval S_OK
* Construct XMLTree Succeed
*
* \retval ERR_OUT_OF_MEMORY
* No enough memory to construct XMLTree
*
******************************************************************************
*/
SCODE XmlWrapper_SetXMLTreeNodeHdl(TXMLElem *ptxeDocRoot, const char *pcPath, StartElemHandler pfStartHdl, XML_CharacterDataHandler pfChDataHdl, XML_EndElementHandler pfEndHdl, TXmlWrapperNamespaceMap *ptNSMap);

/*!
******************************************************************************
* \brief
* Free xml handler tree memory
*
* \param ptxeDocRoot
* \a (i) root of xmltree
*
******************************************************************************
*/
void XmlWrapper_ClearTree(TXMLElem *ptxeRoot);

#endif /* _XMLWRAPPER_OPTIONS_H_*/
