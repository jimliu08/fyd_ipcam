/*
 *******************************************************************************
 * $Header: $
 *
 *  Copyright (c) 2000-2006 VN Inc. All rights reserved.
 *
 *  +-----------------------------------------------------------------+
 *  | THIS SOFTWARE IS FURNISHED UNDER A LICENSE AND MAY ONLY BE USED |
 *  | AND COPIED IN ACCORDANCE WITH THE TERMS AND CONDITIONS OF SUCH  |
 *  | A LICENSE AND WITH THE INCLUSION OF THE THIS COPY RIGHT NOTICE. |
 *  | THIS SOFTWARE OR ANY OTHER COPIES OF THIS SOFTWARE MAY NOT BE   |
 *  | PROVIDED OR OTHERWISE MADE AVAILABLE TO ANY OTHER PERSON. THE   |
 *  | OWNERSHIP AND TITLE OF THIS SOFTWARE IS NOT TRANSFERRED.        |
 *  |                                                                 |
 *  | THE INFORMATION IN THIS SOFTWARE IS SUBJECT TO CHANGE WITHOUT   |
 *  | ANY PRIOR NOTICE AND SHOULD NOT BE CONSTRUED AS A COMMITMENT BY |
 *  | VN INC.                                                    |
 *  +-----------------------------------------------------------------+
 *
 * $History: $
 * 
 */

/*!
 *******************************************************************************
 * Copyright 2000-2006 VN, Inc. All rights reserved.
 *
 * \file
 * XmlWrapper_Mgr.c
 *
 * \brief
 * Parse XML Handler Tree
 *
 * \date
 * 2006/07/19
 *
 * \author
 * Cheng-Ching Huang
 *
 *
 *******************************************************************************
 */
 
#include <stdio.h>
#include <string.h>
#include <expat.h>
#include <assert.h>
#include "dbgdefs.h"
#include "xmlwrapper_local.h"
#include "xmlwrapper_mgr.h"
#define TAB 9
#define SPACE 32

/* ================================================================================= */
void XmlWrapper_startElement(void *userData, const char *name, const char **atts)
{
	TXMLTreeTraverse	*ptxmlTT = userData;	
	const TXMLElem	*ptElem = ptxmlTT->ptCurrentElem->pChild;
	SCODE sRet;
	
#ifdef _DEBUG
	printf("<%s> ", name);
	if (*atts)
	{
		int idx = 0;
				
		do
		{		
			printf("[attr] %s = %s ", atts[idx], atts[idx+1]);
			idx += 2;
		}while(atts[idx]);
	}
	printf("\n");
#endif
	/* I don't know his parent, thus I don't know him. */
	if (ptxmlTT->dwUnknownElemDepth != 0) {
		ptxmlTT->dwUnknownElemDepth ++; 		
		return;
	}
	while (ptElem != 0) {
		if (strcmp(name, ptElem->szAbsoluteName) == 0) {
			ptxmlTT->ptCurrentElem = ptElem;
			if (ptElem->pfStartHdl)	
			{				
				/* Version 1.2.0.0 modification, 2006.12.01 */			
				if ((sRet = ptElem->pfStartHdl(ptxmlTT->hObject, name, atts)) != S_OK)
				{					
					/*if no attr ignore some config*/
					if (sRet == IGNORE_SIBLING_CONFIG)
					{
						DBPRINT0("IgnoreSibling Data\n")
						XmlWrapper_XMLTree_IgnoreSibling(userData);
					}					
					else if (sRet == IGNORE_CHILD_CONFIG)
					{
						DBPRINT0("IgnoreChild Data\n")
						XmlWrapper_XMLTree_IgnoreChild(userData);
					}
				}
				/* ================================================================= */
			}
			return;
		}
		ptElem = ptElem->pSibling; 
	}
	/* I cannot find any element match the name, ignore them. */
	ptxmlTT->dwUnknownElemDepth ++;
#if 0
	int i;
	for (i = 0; i < ptxmlTT->dwUnknownElemDepth; i++) {
		printf("\t");
	}
	printf("%s\n", name);
#endif
}

/* ================================================================================= */
void XmlWrapper_endElement(void *userData, const char *name)
{
	TXMLTreeTraverse	*ptxmlTT = userData;

	DBPRINT1("</%s> \n", name)
	if (ptxmlTT->dwUnknownElemDepth != 0) {
		ptxmlTT->dwUnknownElemDepth --;		
		return;
	}
	if (ptxmlTT->ptCurrentElem->pfEndHdl)
	{
		ptxmlTT->ptCurrentElem->pfEndHdl(ptxmlTT->hObject, name);
	}
	ptxmlTT->ptCurrentElem = ptxmlTT->ptCurrentElem->pParent;
	assert(ptxmlTT->ptCurrentElem != NULL);
}

/* ================================================================================= */
void XmlWrapper_charHandle(void *userData, const XML_Char *s, int len)
{
	TXMLTreeTraverse	*ptxmlTT = userData;
	const TXMLElem	*ptElem = ptxmlTT->ptCurrentElem;
			
	DBPRINT2("%s Node %s\n", __func__, ptElem->szElemName)
	if (ptElem->pfChDataHdl)	
	{		
		DBPRINT0("callback!\n")
		ptElem->pfChDataHdl(ptxmlTT->hObject, s, len);
		DBPRINT0("callback!\n")
	}
	
#ifdef _DEBUG
	XML_Char	szData[1024];	
	memcpy(szData, s, len);
	szData[len] = '\0';
	if (szData[0] != TAB && szData[0] != SPACE && strcmp(szData, "\r") && strcmp(szData, "\n"))
	{
		printf("(%d) %s\n", len, szData);
	}
#endif	
}
#if 0
/* ================================================================================= */
void XmlWrapper_XMLTree_Reunion (TXMLElem *ptParent, TXMLElem *ptChild)
{
	TXMLElem **pptElem;
	TXMLElem *ptElem;

	ptChild->pParent = ptParent;
	pptElem = (TXMLElem **) &(ptParent->pChild);
	ptElem = *pptElem;
	while (ptElem) {
		pptElem = (TXMLElem **)&(ptElem->pSibling);
		ptElem = *pptElem;
	}
	*pptElem = ptChild;
}
#endif
/* ================================================================================= */ 
/* add, 2006.12.01 */
inline void XmlWrapper_XMLTree_IgnoreSibling(void *userData)
{
	TXMLTreeTraverse	*ptxmlTT = userData;
	
	ptxmlTT->ptCurrentElem = ptxmlTT->ptCurrentElem->pParent->pParent;
	ptxmlTT->dwUnknownElemDepth += 2;
//	printf("%s %d : depth %d\n", __FILE__, __LINE__, ptxmlTT->dwUnknownElemDepth);
}

/* ================================================================================= */
/* add, 2006.12.01 */
inline void XmlWrapper_XMLTree_IgnoreChild(void *userData)
{
	TXMLTreeTraverse	*ptxmlTT = userData;
	
	ptxmlTT->ptCurrentElem = ptxmlTT->ptCurrentElem->pParent;
	ptxmlTT->dwUnknownElemDepth ++;
//	printf("%s %d : depth %d\n", __FILE__, __LINE__, ptxmlTT->dwUnknownElemDepth);
}

/* ================================================================================= */
SCODE XmlWrapper_ReadBuf_UsrDefFunc(BYTE *pbyBuffer, HANDLE hXMLWrapperObject, HANDLE hUserData)
{
	XML_Parser parser;
	TXMLWRAPPERInfo *ptxpInfo = (TXMLWRAPPERInfo *) (hXMLWrapperObject);
	TXMLTreeTraverse txmlTT;

	DBPRINT0("XmlWrapper_ReadBuf_UsrDefFunc! \n")
	txmlTT.ptCurrentElem = &ptxpInfo->txeDocRoot;
	DBPRINT3("%s Root(%x) %s\n", __func__, &ptxpInfo->txeDocRoot, txmlTT.ptCurrentElem->pChild->szElemName)	
	txmlTT.dwUnknownElemDepth = 0;
	txmlTT.hObject = hUserData;

	parser = ptxpInfo->parser;
	XML_SetUserData(parser, &txmlTT);
	
	if (XML_Parse(parser, (CHAR*)pbyBuffer, strlen((CHAR*)pbyBuffer), 1) == XML_STATUS_ERROR)
	{
		fprintf(stderr, "%s at line %d\n", XML_ErrorString(XML_GetErrorCode(parser)), (int)XML_GetCurrentLineNumber(parser));
		return S_FAIL;
	}		  

	return S_OK;
}

/* ================================================================================= */
SCODE XmlWrapper_ReadFile_UsrDefFunc(const CHAR *szFileName, HANDLE hXMLWrapperObject, HANDLE hUserData)
{
	char szbuf[BUFSIZ];
	XML_Parser parser;
	TXMLWRAPPERInfo *ptxpInfo = (TXMLWRAPPERInfo *) (hXMLWrapperObject);
	TXMLTreeTraverse	txmlTT;
	int done, iLen;
	int				iFdXML;
	struct flock	tFLock;

	DBPRINT0("XmlWrapper_ReadFile_UsrDefFunc! \n")
	txmlTT.ptCurrentElem = &ptxpInfo->txeDocRoot;
	DBPRINT3("%s Root(%x) %s\n", __func__, &ptxpInfo->txeDocRoot, txmlTT.ptCurrentElem->pChild->szElemName)
	txmlTT.dwUnknownElemDepth = 0;
	txmlTT.hObject = hUserData;

	parser = ptxpInfo->parser;
	XML_SetUserData(parser, &txmlTT);
	
	if ((iFdXML = open(szFileName, O_RDONLY)) < 0)
	{
		return S_FAIL;
	}

	memset(&tFLock, 0, sizeof(struct flock));
	tFLock.l_type	= F_RDLCK;
	tFLock.l_whence	= SEEK_SET;
	tFLock.l_start	= 0;
	tFLock.l_len	= 0;

	while (fcntl(iFdXML, F_SETLKW, &tFLock) == -1)
	{
		if (errno != EINTR)
		{
			close(iFdXML);
			return S_FAIL;
		}
	}

	do {
	  size_t len = read(iFdXML, szbuf, sizeof(szbuf));
	  done = (len == 0);
	  if (XML_Parse(parser, szbuf, len, done) == XML_STATUS_ERROR) {			  
		fprintf(stderr,
				"%s at line %d\n",
				XML_ErrorString(XML_GetErrorCode(parser)),
				(int)XML_GetCurrentLineNumber(parser));
		close(iFdXML);
		return S_FAIL;
	  }		  
	} while (!done);

	memset(&tFLock, 0, sizeof(struct flock));
	tFLock.l_type	= F_UNLCK;
	tFLock.l_whence	= SEEK_SET;
	tFLock.l_start	= 0;
	tFLock.l_len	= 0;

	fcntl(iFdXML, F_SETLK, &tFLock);
	close(iFdXML);

	/* save filename for reloading */
	iLen = strlen(szFileName);
	memcpy(ptxpInfo->szFileName, szFileName, iLen);
	ptxpInfo->szFileName[iLen] = '\0';
//	printf("%s:%d Parse %s success!\n", __FILE__, __LINE__, ptxpInfo->szFileName);

	return S_OK;
}

#if 0
/* ================================================================================= */
SCODE XmlWrapper_ReloadFile_UsrDefFunc(const CHAR *szFileName, HANDLE hXMLWrapperObject, HANDLE hUserData)
{						
	if ( XmlWrapper_Reset(hXMLWrapperObject) != S_OK)
	{	
		fprintf(stderr, "%s:%s Fail!!\n", __FILE__, __func__);
		return S_FAIL;
	}

	return XmlWrapper_ReadFile_UsrDefFunc(szFileName, hXMLWrapperObject, hUserData);	
}
#endif

/* ================================================================================= */
SCODE XmlWrapper_ReadFile_UsrDefFunc_SameXmlHdl(const CHAR *szFileName, HANDLE hXMLWrapperObject, HANDLE hUserData)
{
	TXMLWRAPPERInfo *ptInfo = (TXMLWRAPPERInfo *) hXMLWrapperObject;			
	
	//printf("%s:%d PreFile:%s usrinput: %s\n", __FILE__, __LINE__, ptInfo->szFileName, szFileName);
	if ( XmlWrapper_Reset(hXMLWrapperObject) != S_OK)
	{	
		fprintf(stderr, "%s:%s Fail!!\n", __FILE__, __func__);
		return S_FAIL;
	}
	
	/* reloading */
	if (! szFileName)
	{
		return XmlWrapper_ReadFile_UsrDefFunc(ptInfo->szFileName, hXMLWrapperObject, hUserData);
	}
	/* parsing new conf file with the same TreeMap Handler */
	else
	{
		return XmlWrapper_ReadFile_UsrDefFunc(szFileName, hXMLWrapperObject, hUserData);
	}	
}

SCODE XmlWrapper_ReadBuf_UsrDefFunc_SameXmlHdl(BYTE *pbyBuffer, HANDLE hXMLWrapperObject, HANDLE hUserData)
{
	if ( XmlWrapper_Reset(hXMLWrapperObject) != S_OK)
	{	
		fprintf(stderr, "%s:%s Fail!!\n", __FILE__, __func__);
		return S_FAIL;
	}

	return XmlWrapper_ReadBuf_UsrDefFunc(pbyBuffer, hXMLWrapperObject, hUserData);
}
