/*
 *******************************************************************************
 * $Header: $
 *
 *  Copyright (c) 2000-2004 VN Inc. All rights reserved.
 *
 *  +-----------------------------------------------------------------+
 *  | THIS SOFTWARE IS FURNISHED UNDER A LICENSE AND MAY ONLY BE USED |
 *  | AND COPIED IN ACCORDANCE WITH THE TERMS AND CONDITIONS OF SUCH  |
 *  | A LICENSE AND WITH THE INCLUSION OF THE THIS COPY RIGHT NOTICE. |
 *  | THIS SOFTWARE OR ANY OTHER COPIES OF THIS SOFTWARE MAY NOT BE   |
 *  | PROVIDED OR OTHERWISE MADE AVAILABLE TO ANY OTHER PERSON. THE   |
 *  | OWNERSHIP AND TITLE OF THIS SOFTWARE IS NOT TRANSFERRED.        |
 *  |                                                                 |
 *  | THE INFORMATION IN THIS SOFTWARE IS SUBJECT TO CHANGE WITHOUT   |
 *  | ANY PRIOR NOTICE AND SHOULD NOT BE CONSTRUED AS A COMMITMENT BY |
 *  | VN INC.                                                    |
 *  +-----------------------------------------------------------------+
 *
 * $History: $
 * 
 */

/*!
 *******************************************************************************
 * Copyright 2000-2006 VN, Inc. All rights reserved.
 *
 * \file
 * XmlWrapper_Options.c
 *
 * \brief
 * Set startElem and ChData Handler
 *
 * \date
 * 2006/12/01
 *
 * \author
 * Ming-Jing Tsai
 *
 *
 *******************************************************************************
 */
#include <stdio.h>
#include <string.h>
#include <expat.h>
#include <assert.h>
#include "dbgdefs.h"
#include "xmlwrapper.h"
#include "xmlwrapper_local.h"
#include "xmlwrapper_options.h"

SCODE XmlWrapper_SetXMLTreeNodeHdl(TXMLElem *ptxeDocRoot, const char *pcPath, StartElemHandler pfStartHdl, XML_CharacterDataHandler pfChDataHdl, XML_EndElementHandler pfEndHdl, TXmlWrapperNamespaceMap *ptNSMap)
{
	CHAR *szSub, acTmp[PATH_SIZE], *pcTmp;
	TXMLElem *ptxePointer, **pptxePointer, *ptxeParentPointer;

	strcpy(acTmp, pcPath);	
	ptxeParentPointer = ptxeDocRoot;
	szSub = strtok_r(acTmp, "/", &pcTmp);
	do
	{		
		DBPRINT1("Node[%s] : \n", szSub)
		pptxePointer = &ptxeParentPointer->pChild;
		ptxePointer = ptxeParentPointer->pChild;
	
		/*traverse levelwise*/
		while (ptxePointer != NULL)
		{	
			DBPRINT1(" Current Tree Node[%s] ", ptxePointer->szElemName)
			if (strcmp(ptxePointer->szElemName, szSub) == 0)
			{				
				DBPRINT0(" ->Find!! \n")
				break;				
			}
			else
			{
				DBPRINT0(" ->Traverse Sib ")
				pptxePointer = &ptxePointer->pSibling;			
				ptxePointer = ptxePointer->pSibling;			
			}	
		}//while traverse level element		
		/*construct level element node */
		if (ptxePointer == NULL)
		{			
			DBPRINT1(" ->Not found-> Add [%s]\n", szSub)
			// Create a new element node
			if ((ptxePointer=malloc(sizeof(TXMLElem))) == NULL)
			{
				printf("%s:%d : request memory fail\n", __FILE__, __LINE__);
				return ERR_OUT_OF_MEMORY;
			}
			memset(ptxePointer, 0, sizeof(TXMLElem));

			if ((ptxePointer->szElemName=strdup(szSub)) == NULL)
			{
				printf("%s:%d : request memory fail\n", __FILE__, __LINE__);
				free(ptxePointer);
				return ERR_OUT_OF_MEMORY;
			}
			// add absolute name here, it should take care no prefix condition
			{
				char *szPrefix, acTmp[PATH_SIZE], *pcTmp;
				char szAbsoluteName[256];
				// if it has prefix
				if (strchr(szSub, ':') != NULL) {
					strcpy(acTmp, szSub);
					szPrefix = strtok_r(acTmp, ":", &pcTmp);
					if (ptNSMap != NULL) {
						while (ptNSMap->szPrefix != NULL) {
							if (strcmp(szPrefix, ptNSMap->szPrefix) == 0) {
								DBPRINT2("Prefix: %s, Namespace: %s\n", szPrefix, ptNSMap->szNamespace)
								szPrefix = strtok_r(NULL, ":", &pcTmp);
								// assign to szAbsoluteName name
								sprintf(szAbsoluteName, "%s:%s", ptNSMap->szNamespace, szPrefix);
								DBPRINT1("szAbsoluteName: %s\n", szAbsoluteName)
								ptxePointer->szAbsoluteName = strdup(szAbsoluteName);							
								break;
							}
							ptNSMap++;
						}
					}
					// because no prefix match
					if (ptxePointer->szAbsoluteName == NULL) {
						ptxePointer->szAbsoluteName = strdup(szSub);
					}
				} else {
					ptxePointer->szAbsoluteName = strdup(szSub);
				}
			}
			// hook this element node to the tree
			ptxePointer->pParent = ptxeParentPointer;
			*pptxePointer = ptxePointer;
		}//if not found node name		
		
		ptxeParentPointer = ptxePointer;
	}while((szSub=strtok_r(NULL, "/", &pcTmp)));//while node path

	ptxePointer->pfStartHdl = pfStartHdl;
	ptxePointer->pfChDataHdl = pfChDataHdl;
	ptxePointer->pfEndHdl = pfEndHdl;

	return S_OK;

}//XMLWrapper_XMLTree_SetHandler
 
void XmlWrapper_ClearTree(TXMLElem *ptxeRoot)
{
	TXMLElem *ptxePointer, *ptxeSibPointer;

	ptxePointer = ptxeRoot;
	DBPRINT1("%s \n", ptxePointer->szElemName)
	if (ptxePointer->pChild)
	{
		DBPRINT0("Child ")
		XmlWrapper_ClearTree(ptxePointer->pChild);
	}
	ptxeSibPointer = ptxePointer->pSibling;
	DBPRINT1("Free %s \n", ptxePointer->szElemName)
	free(ptxePointer->szElemName);
	free(ptxePointer->szAbsoluteName);
	free(ptxePointer);
	if (ptxeSibPointer)
	{
		DBPRINT0("Sibling ")
		XmlWrapper_ClearTree(ptxeSibPointer);
	}	
}//XmlWrapper_TraverseTree

SCODE XmlWrapper_SetHandler(HANDLE hXmlWrapperObject, TXmlWrapperTreeMap *ptTreeMap, TXmlWrapperNamespaceMap *ptNSMap)
{
	SCODE sRet;
	TXMLWRAPPERInfo *ptxpInfo = (TXMLWRAPPERInfo *) (hXmlWrapperObject);	
	
	//=== Clear Xml handler tree	
	if (ptxpInfo->txeDocRoot.pChild)
	{		
		XmlWrapper_ClearTree(ptxpInfo->txeDocRoot.pChild);
		ptxpInfo->txeDocRoot.pChild = NULL;
		//debug_printf("Clear handler tree succeed!\n");
	}	
	while(ptTreeMap->szElemName != NULL)
	{
		DBPRINT1("Create Path : %s\n", ptTreeMap->szElemName)
		if ((sRet = XmlWrapper_SetXMLTreeNodeHdl(&ptxpInfo->txeDocRoot, ptTreeMap->szElemName, ptTreeMap->pfStartHdl, ptTreeMap->pfChDataHdl, ptTreeMap->pfEndHdl, ptNSMap)) != S_OK)
		{
			return sRet;
		}
		ptTreeMap++;
	}	
			
	return S_OK;

}//XMLWrapper_XMLTree_ConstructXMLTree

