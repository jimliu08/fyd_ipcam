/*
 *******************************************************************************
 * $Header: $
 *
 *  Copyright (c) 2000-2004 VN Inc. All rights reserved.
 *
 *  +-----------------------------------------------------------------+
 *  | THIS SOFTWARE IS FURNISHED UNDER A LICENSE AND MAY ONLY BE USED |
 *  | AND COPIED IN ACCORDANCE WITH THE TERMS AND CONDITIONS OF SUCH  |
 *  | A LICENSE AND WITH THE INCLUSION OF THE THIS COPY RIGHT NOTICE. |
 *  | THIS SOFTWARE OR ANY OTHER COPIES OF THIS SOFTWARE MAY NOT BE   |
 *  | PROVIDED OR OTHERWISE MADE AVAILABLE TO ANY OTHER PERSON. THE   |
 *  | OWNERSHIP AND TITLE OF THIS SOFTWARE IS NOT TRANSFERRED.        |
 *  |                                                                 |
 *  | THE INFORMATION IN THIS SOFTWARE IS SUBJECT TO CHANGE WITHOUT   |
 *  | ANY PRIOR NOTICE AND SHOULD NOT BE CONSTRUED AS A COMMITMENT BY |
 *  | VN INC.                                                    |
 *  +-----------------------------------------------------------------+
 *
 * $History: $
 * 
 */

/*!
 *******************************************************************************
 * Copyright 2000-2006 VN, Inc. All rights reserved.
 *
 * \file
 * XmlWrapper_Setup.c
 *
 * \brief
 * construct XML tree
 *
 * \date
 * 2006/12/01
 *
 * \author
 * Ming-Jing Tsai
 *
 *
 *******************************************************************************
 */

#include <vivo_codec.h>
#include <stdio.h>
#include <expat.h>
#include <typedef.h>
#include <string.h>
#include "xmlwrapper_local.h"
#include "xmlwrapper_mgr.h"
#include "xmlwrapper_options.h"		  

//extern TXMLElem txeDocRoot;
/* ================================================================================= */
SCODE XmlWrapper_Initial(HANDLE *phObject, TXmlWrapperInitOptions *ptInitOptions)
{
	TXMLWRAPPERInfo *ptInfo;

	if (((ptInitOptions->dwVersion & 0x00FF00FF)!=(XMLWRAPPER_VERSION & 0x00FF00FF)) ||
		((ptInitOptions->dwVersion & 0x0000FF00)>(XMLWRAPPER_VERSION & 0x0000FF00)))
	{		
		printf("Invalid XML_WRAPPER library version %d.%d.%d.%d !!\n", (SHORT) ptInitOptions->dwVersion&0xFF, (SHORT) (ptInitOptions->dwVersion>>8)&0xFF, (SHORT) (ptInitOptions->dwVersion>>16)&0xFF, (SHORT) (ptInitOptions->dwVersion>>24)&0xFF);
		return ERR_INVALID_VERSION;
	}
	//printf("Start to use XmlWrapper library version %d.%d.%d.%d !!\n", (SHORT) ptInitOptions->dwVersion&0xFF, (SHORT) (ptInitOptions->dwVersion>>8)&0xFF, (SHORT) (ptInitOptions->dwVersion>>16)&0xFF, (SHORT) (ptInitOptions->dwVersion>>24)&0xFF);
	if ((ptInfo=malloc(sizeof(TXMLWRAPPERInfo))) == NULL)
	{
		printf("Allocate memory not enough! \n");
		return ERR_OUT_OF_MEMORY;
	}
	memset(ptInfo, 0, sizeof(TXMLWRAPPERInfo));
	*phObject = (HANDLE) ptInfo;
	
	if ((ptInfo->parser=XML_ParserCreateNS(NULL, ':')) == NULL)
	{
		printf("XML_ParserCreate failed!\n");
		goto error_handle;
	}
	//======== Set-up the callback function 
	XML_SetElementHandler(ptInfo->parser, XmlWrapper_startElement, XmlWrapper_endElement);
	XML_SetCharacterDataHandler(ptInfo->parser, XmlWrapper_charHandle);

	return S_OK;
error_handle:
	XmlWrapper_Release(phObject);
	return S_FAIL;
}

/* ================================================================================= */
SCODE XmlWrapper_Reset(HANDLE hObject)
{
	TXMLWRAPPERInfo *ptInfo;		
	
	//==== Reset XML Parser
	ptInfo = (TXMLWRAPPERInfo *) (hObject);
	if (XML_ParserReset(ptInfo->parser, NULL) == XML_FALSE)
	{
		printf("Expat Reset Fail \n");
		return S_FAIL;
	}	
	//=== Set-up the callback function
	XML_SetElementHandler(ptInfo->parser, XmlWrapper_startElement, XmlWrapper_endElement);
	XML_SetCharacterDataHandler(ptInfo->parser, XmlWrapper_charHandle);		

	return S_OK;
}

/* ================================================================================= */
SCODE XmlWrapper_Release(HANDLE *phObject)
{
	TXMLWRAPPERInfo *ptxpInfo=(TXMLWRAPPERInfo *)(*phObject);

	/* free xml handler tree memory */	
	if (ptxpInfo->txeDocRoot.pChild != NULL)
	{
		XmlWrapper_ClearTree(ptxpInfo->txeDocRoot.pChild);
	}
	
	if (ptxpInfo->parser != NULL)
	{
		XML_ParserFree(ptxpInfo->parser);
	}

	free(ptxpInfo);
	*phObject = NULL;

	return S_OK;
}
