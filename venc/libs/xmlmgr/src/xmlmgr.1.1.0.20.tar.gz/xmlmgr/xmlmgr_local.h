/*
 *******************************************************************************
 * $Header: $
 *
 *  Copyright (c) 2000-2006 VN Inc. All rights reserved.
 *
 *  +-----------------------------------------------------------------+
 *  | THIS SOFTWARE IS FURNISHED UNDER A LICENSE AND MAY ONLY BE USED |
 *  | AND COPIED IN ACCORDANCE WITH THE TERMS AND CONDITIONS OF SUCH  |
 *  | A LICENSE AND WITH THE INCLUSION OF THE THIS COPY RIGHT NOTICE. |
 *  | THIS SOFTWARE OR ANY OTHER COPIES OF THIS SOFTWARE MAY NOT BE   |
 *  | PROVIDED OR OTHERWISE MADE AVAILABLE TO ANY OTHER PERSON. THE   |
 *  | OWNERSHIP AND TITLE OF THIS SOFTWARE IS NOT TRANSFERRED.        |
 *  |                                                                 |
 *  | THE INFORMATION IN THIS SOFTWARE IS SUBJECT TO CHANGE WITHOUT   |
 *  | ANY PRIOR NOTICE AND SHOULD NOT BE CONSTRUED AS A COMMITMENT BY |
 *  | VN INC.                                                    |
 *  +-----------------------------------------------------------------+
 *
 * $History: $
 * 
 *******************************************************************************
 */

/*!
 *******************************************************************************
 * Copyright 2000-2006 VN, Inc. All rights reserved.
 *
 * \file
 * xmlmgr_local.h
 *
 * \brief
 * XML configuration file parsing (read/write) library local header file
 *
 * \date
 * 2006/08/24
 *
 * \author
 * Rey Cheng
 *
 *
 *******************************************************************************
 */

#ifndef _XMLMGR_LOCAL_H_
#define _XMLMGR_LOCAL_H_

#include "expat.h"
#include "xmlmgr.h"
#include "xmlmgr_writer.h"
#include "dbgdefs.h"
#include <assert.h>
#include <stdio.h>
#include <sys/file.h>
#include <unistd.h>
#include <errno.h>


#define NAME_SIZE	64
#define VALUE_SIZE	64
#define LEAST_VALUE_SIZE	64
#define XML_DECA_SZ	256	// xml declaration buffer size

typedef enum xml_tree_node_op
{
	/*! reset tree node */
	extnoReset,
	/*! free tree node */
	extnoFree
} EXMLTreeNodeOp;

typedef enum xsd_node_type
{
	/*! simple : string */
	exntString,
	/*! simple : integer */
	exntInteger,
	/*! complex */
	exntComplex
} EXSDNodeType;

typedef struct xsd_int_restricts
{
	LONG	lMin;
	LONG	lMax;
} TXSDIntRestricts;

// TODO : string restrictions
/*
typedef struct xsd_str_restricts
{
	
} TXSDStrRestricts;
*/

typedef struct xsd_list_node
{
	// node name
	char	szElemName[NAME_SIZE];
	// node type
	EXSDNodeType exntNodeType;
	// restrictions, only valid in simple type
	void	*pRestrictions;
	struct xsd_list_node *pNext;
} TXSDListNode;

/* attribute node */
typedef struct xml_attr_elem
{
	char szAttrName[NAME_SIZE];
	char szAttrValue[VALUE_SIZE];
	struct xml_attr_elem *pNext;
}TXMLAttrElem;

typedef struct xml_elem_t
{
	char	szElemName[NAME_SIZE];
	// 2010/05/25 modified by djhow
	char	*szElemValue;
	BOOL	bFirstIn;
	DWORD	dwElemValueBufSz;
	/*! added 2007/04/11 , attrbute node list */
	TXMLAttrElem *ptAttrElemList;			
	struct xml_elem_t *pParent;
	struct xml_elem_t *pChild;
	struct xml_elem_t *pSibling;
} TXMLElem;

typedef struct xml_mgr_info
{
	XML_Parser		xpParser;
	TXMLElem		*ptxeRoot;
	TXMLElem		*ptxePointer;

	char			szXSDSrc[256];
	TXSDListNode	*ptXSDList;
	TXSDListNode	*ptXSDPointer;
	// Print 'tab' by depth value in XmlConf_WriteFile()
	int				iDepth;
	// Determine the stack size in XmlConf_WriteFile()
	DWORD			dwEleNum;
	DWORD			dwStackTop;
	char			**szStack;

	char			*pcRdFileBuf;
	char			szXmlDeca[XML_DECA_SZ];
} TXMLMgrInfo;

TXMLElem *XmlMgr_NewElem(void);
void XmlMgr_FreeElem(TXMLElem *ptElem);
SCODE XmlMgr_Elem_SetValue(TXMLElem *ptElem, const CHAR *szValue, int iValueLen);

#endif /* _XMLMGR_LOCAL_H_ */
