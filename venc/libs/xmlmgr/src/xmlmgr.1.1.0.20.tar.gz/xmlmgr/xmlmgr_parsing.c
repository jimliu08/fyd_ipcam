/*
 *******************************************************************************
 * $Header: $
 *
 *  Copyright (c) 2000-2006 VN Inc. All rights reserved.
 *
 *  +-----------------------------------------------------------------+
 *  | THIS SOFTWARE IS FURNISHED UNDER A LICENSE AND MAY ONLY BE USED |
 *  | AND COPIED IN ACCORDANCE WITH THE TERMS AND CONDITIONS OF SUCH  |
 *  | A LICENSE AND WITH THE INCLUSION OF THE THIS COPY RIGHT NOTICE. |
 *  | THIS SOFTWARE OR ANY OTHER COPIES OF THIS SOFTWARE MAY NOT BE   |
 *  | PROVIDED OR OTHERWISE MADE AVAILABLE TO ANY OTHER PERSON. THE   |
 *  | OWNERSHIP AND TITLE OF THIS SOFTWARE IS NOT TRANSFERRED.        |
 *  |                                                                 |
 *  | THE INFORMATION IN THIS SOFTWARE IS SUBJECT TO CHANGE WITHOUT   |
 *  | ANY PRIOR NOTICE AND SHOULD NOT BE CONSTRUED AS A COMMITMENT BY |
 *  | VN INC.                                                    |
 *  +-----------------------------------------------------------------+
 *
 * $History: $
 * 
 *******************************************************************************
 */

/*!
 *******************************************************************************
 * Copyright 2000-2006 VN, Inc. All rights reserved.
 *
 * \file
 * xmlmgr.c
 *
 * \brief
 * XML configuration file parsing (read/write) library - default parsing function for XmlMgr parsing map
 *
 * \date
 * 2006/08/24
 *
 * \author
 * Rey Cheng
 *
 *
 *******************************************************************************
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "xmlmgr.h"

void xmlmgr_set_string(char *szConfValue, void *pObj)
{
//	*(char **) pObj = strdup(szConfValue);
	sprintf((char *) pObj, "%s", szConfValue);
//fprintf(stderr, "%s %d : %p %s\n", __FILE__, __LINE__, pObj, (char *)pObj);
	return;
}

// four byte - signed
void xmlmgr_set_long(char *szConfValue, void *pObj)
{
	char *pcEnd;
	//*(int *) pObj = atoi(szConfValue);
	*(LONG *) pObj = (LONG) strtol(szConfValue, &pcEnd, 10);
//fprintf(stderr, "%s %d : %s %p %d\n", __FILE__, __LINE__, szConfValue, pObj, *(LONG *)pObj);
	return;
}

// two byte - signed
void xmlmgr_set_short(char *szConfValue, void *pObj)
{
	char *pcEnd;
	//*(int *) pObj = atoi(szConfValue);
	*(SHORT *) pObj = (SHORT) strtol(szConfValue, &pcEnd, 10);
//fprintf(stderr, "%s %d : %s %p %d\n", __FILE__, __LINE__, szConfValue, pObj, *(SHORT *)pObj);
	return;
}
