/*
 *******************************************************************************
 * $Header: $
 *
 *  Copyright (c) 2000-2006 VN Inc. All rights reserved.
 *
 *  +-----------------------------------------------------------------+
 *  | THIS SOFTWARE IS FURNISHED UNDER A LICENSE AND MAY ONLY BE USED |
 *  | AND COPIED IN ACCORDANCE WITH THE TERMS AND CONDITIONS OF SUCH  |
 *  | A LICENSE AND WITH THE INCLUSION OF THE THIS COPY RIGHT NOTICE. |
 *  | THIS SOFTWARE OR ANY OTHER COPIES OF THIS SOFTWARE MAY NOT BE   |
 *  | PROVIDED OR OTHERWISE MADE AVAILABLE TO ANY OTHER PERSON. THE   |
 *  | OWNERSHIP AND TITLE OF THIS SOFTWARE IS NOT TRANSFERRED.        |
 *  |                                                                 |
 *  | THE INFORMATION IN THIS SOFTWARE IS SUBJECT TO CHANGE WITHOUT   |
 *  | ANY PRIOR NOTICE AND SHOULD NOT BE CONSTRUED AS A COMMITMENT BY |
 *  | VN INC.                                                    |
 *  +-----------------------------------------------------------------+
 *
 * $History: $
 * 
 *******************************************************************************
 */

/*!
 *******************************************************************************
 * Copyright 2000-2006 VN, Inc. All rights reserved.
 *
 * \file
 * xmlmgr_xsd.h
 *
 * \brief
 * XML configuration file parsing (read/write) library - XSD (XML Schema Definition) expat handler header file
 *
 * \date
 * 2006/11/02
 *
 * \author
 * Rey Cheng
 *
 *
 *******************************************************************************
 */

#if 0

#ifndef _XMLMGR_XSD_H_
#define _XMLMGR_XSD_H_

#include "xmlmgr_local.h"

SCODE XmlMgr_ParsingXSD(TXMLMgrInfo *pThis, FILE *fpXSDSrc);
SCODE XmlMgr_ResetXSD(TXMLMgrInfo *pThis);
SCODE XmlMgr_ReleaseXSD(TXMLMgrInfo *pThis);

#endif /* _XMLMGR_XSD_H_ */

#endif
