/*
 *******************************************************************************
 * $Header: $
 *
 *  Copyright (c) 2000-2006 VN Inc. All rights reserved.
 *
 *  +-----------------------------------------------------------------+
 *  | THIS SOFTWARE IS FURNISHED UNDER A LICENSE AND MAY ONLY BE USED |
 *  | AND COPIED IN ACCORDANCE WITH THE TERMS AND CONDITIONS OF SUCH  |
 *  | A LICENSE AND WITH THE INCLUSION OF THE THIS COPY RIGHT NOTICE. |
 *  | THIS SOFTWARE OR ANY OTHER COPIES OF THIS SOFTWARE MAY NOT BE   |
 *  | PROVIDED OR OTHERWISE MADE AVAILABLE TO ANY OTHER PERSON. THE   |
 *  | OWNERSHIP AND TITLE OF THIS SOFTWARE IS NOT TRANSFERRED.        |
 *  |                                                                 |
 *  | THE INFORMATION IN THIS SOFTWARE IS SUBJECT TO CHANGE WITHOUT   |
 *  | ANY PRIOR NOTICE AND SHOULD NOT BE CONSTRUED AS A COMMITMENT BY |
 *  | VN INC.                                                    |
 *  +-----------------------------------------------------------------+
 *
 * $History: $
 * 
 *******************************************************************************
 */

/*!
 *******************************************************************************
 * Copyright 2000-2006 VN, Inc. All rights reserved.
 *
 * \file
 * xmlmgr.c
 *
 * \brief
 * XML configuration file parsing (read/write) library
 *
 * \date
 * 2006/08/24
 *
 * \author
 * Rey Cheng
 *
 *
 *******************************************************************************
 */

#include <stdio.h>
#include <string.h>
#include "xmlmgr_local.h"
#include "xmlmgr_handler.h"
#include "xmlmgr_xsd.h"

static const char id[] = "$Id: xmlmgr.c 41873 2011-11-08 13:44:16Z djhow $";

#define BUFFSIZE	128 //8192

static SCODE XmlMgr_ApplyOpToTreeNode(TXMLElem *ptxePointer, EXMLTreeNodeOp extnoOp)
{
	// if sibling exists
	if (ptxePointer->pSibling)
	{
		XmlMgr_ApplyOpToTreeNode(ptxePointer->pSibling, extnoOp);
	}
	// if child exists
	if (ptxePointer->pChild)
	{
		XmlMgr_ApplyOpToTreeNode(ptxePointer->pChild, extnoOp);
	}
	if (extnoOp == extnoFree)
	{
		/*free attr node list, added by Erin 2007/04/13 */
		if(ptxePointer->ptAttrElemList)
		{
			TXMLAttrElem *ptxaeAttrNode = ptxePointer->ptAttrElemList;
			TXMLAttrElem *ptxaeNextAttr;
			do
			{
				ptxaeNextAttr = ptxaeAttrNode->pNext;
				free(ptxaeAttrNode);
				ptxaeAttrNode = ptxaeNextAttr;
			}while(ptxaeAttrNode);
		}		
		// 2010/05/25 modified by djhow
#if 0
		// 2010/05/18 added by djhow
		if (ptxePointer->szElemValue != NULL)
		{
			free(ptxePointer->szElemValue);
		}
		free (ptxePointer);
#endif
		XmlMgr_FreeElem(ptxePointer);

		ptxePointer = NULL;
	}
	else if (extnoOp == extnoReset)
	{
		memset(ptxePointer->szElemName, 0, sizeof(ptxePointer->szElemName));
		// 2010/05/25 modified by djhow
#if 0
		if (ptxePointer->szElemValue != NULL)
		{
			free(ptxePointer->szElemValue);
			ptxePointer->szElemValue	= NULL;
		}
#endif
		memset(ptxePointer->szElemValue, 0, ptxePointer->dwElemValueBufSz);

		/* clear attr node list, added by Erin 2007/04/13  */		
		if(ptxePointer->ptAttrElemList)
		{
			TXMLAttrElem *ptxaeAttrNode = (TXMLAttrElem *)ptxePointer->ptAttrElemList;			
			do
			{				
				memset(&(ptxaeAttrNode->szAttrName), 0, NAME_SIZE);
				memset(&(ptxaeAttrNode->szAttrValue), 0, VALUE_SIZE);
				ptxaeAttrNode = ptxaeAttrNode->pNext;
			}while(ptxaeAttrNode);
		}		
	}
	return S_OK;
}

SCODE XmlMgr_Initial(HANDLE *phObject, TXmlMgrInitOptions *pInitOpts)
{
	TXMLMgrInfo		*pThis;

	assert(phObject && pInitOpts);

	/* =========================================================================
	   check version
	*/
    if (((pInitOpts->dwVersion&0x00FF00FF) != (XMLMGR_VERSION&0x00FF00FF)) |
		((pInitOpts->dwVersion&0x0000FF00) > (XMLMGR_VERSION&0x0000FF00)))
    {
        return ERR_INVALID_VERSION;
    }

	if ((pThis = calloc(1, sizeof(TXMLMgrInfo))) == NULL)
	{
		return ERR_OUT_OF_MEMORY;
	}
	*phObject	= pThis;

	if ((pThis->ptxeRoot = XmlMgr_NewElem()) == NULL)
	{
		goto error_handle;
	}
	pThis->ptxeRoot->bFirstIn = TRUE;
	if (XmlMgr_Elem_SetValue(pThis->ptxeRoot, "_root", sizeof("_root")-1) != S_OK)
	{
		goto error_handle;
	}
	// set current pointer to root
	pThis->ptxePointer	= pThis->ptxeRoot;

	if ((pThis->xpParser = XML_ParserCreate(NULL)) == NULL)
	{
		DBPRINT0("Couldn't allocate memory for parser\n");
		goto error_handle;
	}
	// set user data
	XML_SetUserData(pThis->xpParser, pThis);
	/* set element handler */
	XML_SetElementHandler(pThis->xpParser, XmlMgr_StartElementHandler, XmlMgr_EndElementHandler);
	/* set char data handler */
	XML_SetCharacterDataHandler(pThis->xpParser, XmlMgr_CharacterDataHandler);

	return S_OK;
error_handle:
	XmlMgr_Release(phObject);
	return S_FAIL;
}

SCODE XmlMgr_Release(HANDLE *phObject)
{
	TXMLMgrInfo		*pThis;

	assert(phObject && *phObject);

	pThis = (TXMLMgrInfo *)*phObject;

	if (pThis->pcRdFileBuf != NULL)
	{
		free(pThis->pcRdFileBuf);
	}
	if (pThis->xpParser != NULL)
	{
		XML_ParserFree(pThis->xpParser);
	}
	// free xml tree, find root's first child
	pThis->ptxePointer = pThis->ptxeRoot->pChild;
	if (pThis->ptxePointer != NULL)
	{
		if (XmlMgr_ApplyOpToTreeNode(pThis->ptxePointer, extnoFree) != S_OK)
		{
			return S_FAIL;
		}
		XmlMgr_FreeElem(pThis->ptxeRoot);
		pThis->ptxeRoot = NULL;
	}

	// release XSD
#if 0
	XmlMgr_ReleaseXSD(pThis);
#endif
	free(*phObject);
	*phObject = NULL;

	return S_OK;
}

SCODE XmlMgr_ReadFile(HANDLE hObject, const char *szFileName)
{
	TXMLMgrInfo		*pThis = (TXMLMgrInfo *) hObject;
	//char			acBuf[BUFFSIZE];
	int				iFd;
	int				iLength, iDone;
	struct flock	tFLock;
	int				iFirst;

	if (pThis->pcRdFileBuf == NULL)
	{
		pThis->pcRdFileBuf = calloc(1, BUFFSIZE);
		if (pThis->pcRdFileBuf == NULL)
		{
			printf("%s calloc faile!\n", __func__);
			return S_FAIL;
		}
	}

	iFd = open(szFileName, O_RDONLY);
	if (iFd < 0)
	{
		fprintf(stderr, "%s:%d Open %s Fail!\n", __FILE__, __LINE__, szFileName);
		return S_FAIL;
	}

	memset(&tFLock, 0, sizeof(struct flock));
	tFLock.l_type	= F_RDLCK;
	tFLock.l_whence	= SEEK_SET;
	tFLock.l_start	= 0;
	tFLock.l_len	= 0;

	while (fcntl(iFd, F_SETLKW, &tFLock) == -1)
	{
		if (errno != EINTR)
		{
			goto error_exit;
		}
	}

	iDone = 0;
	iFirst=1;
	pThis->szXmlDeca[0] = '\0';
	for (; ; )
	{
		iLength = read(iFd, pThis->pcRdFileBuf, BUFFSIZE);
		if (iLength == 0)
		{
			iDone = 1;
		}
		else if (iFirst == 1)
		{
			if (!strncmp(pThis->pcRdFileBuf, "<?xml", sizeof("<?xml") - 1))
			{
				char *pcTmp = strstr(pThis->pcRdFileBuf, "?>");
				if (pcTmp != NULL)
				{
					int iLen;
					pcTmp += sizeof("?>") - 1;
					iLen = pcTmp - pThis->pcRdFileBuf;
					memcpy(pThis->szXmlDeca, pThis->pcRdFileBuf, iLen);
					pThis->szXmlDeca[iLen] = '\0';
				}
				//printf("first line is %s\n", pThis->szXmlDeca);
			}
			iFirst = 0;
		}

		if (XML_Parse(pThis->xpParser, pThis->pcRdFileBuf, iLength, iDone) == XML_STATUS_ERROR)
		{
			fprintf(stderr, "Parse error at line %d:\n%s\n", 
				XML_GetCurrentLineNumber(pThis->xpParser), XML_ErrorString(XML_GetErrorCode(pThis->xpParser)));
			goto error_exit;
		}

		if (iDone)
		{
			break;
		}
	}
	memset(&tFLock, 0, sizeof(struct flock));
	tFLock.l_type	= F_UNLCK;
	tFLock.l_whence	= SEEK_SET;
	tFLock.l_start	= 0;
	tFLock.l_len	= 0;

	fcntl(iFd, F_SETLK, &tFLock);
	close(iFd);

	return S_OK;
error_exit:
	close(iFd);
	return S_FAIL;
}

SCODE XmlMgr_Dump(TXMLMgrInfo *pThis, TXMLElem *ptxeEle, HANDLE hWriter)
{
	int i;

	if (strlen(ptxeEle->szElemName) == 0)
	{
		pThis->iDepth--;
		return S_OK;
	}
	for (i=0; i<pThis->iDepth; i++)
	{
		writer_write(hWriter, "\t", sizeof("\t")-1);
	}
	if ((! strcmp(ptxeEle->szElemName, "root")) && (pThis->ptXSDList != NULL))
	{
		writer_write(hWriter, "<root xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:noNamespaceSchemaLocation=\"", sizeof("<root xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:noNamespaceSchemaLocation=\"")-1);
		writer_write(hWriter, pThis->szXSDSrc, strlen(pThis->szXSDSrc));
		writer_write(hWriter, "\">", sizeof("\">")-1);
	}
	else
	{
		writer_write(hWriter, "<", sizeof("<")-1);
		writer_write(hWriter, ptxeEle->szElemName, strlen(ptxeEle->szElemName));
		/*write attr*/
		if(ptxeEle->ptAttrElemList)
		{
			TXMLAttrElem *ptxaeAttrPtr = (TXMLAttrElem *)ptxeEle->ptAttrElemList;
			do
			{
				writer_write(hWriter, " ", sizeof(" ")-1);
				writer_write(hWriter, ptxaeAttrPtr->szAttrName, strlen(ptxaeAttrPtr->szAttrName));
				writer_write(hWriter, "=\"", sizeof("=\"")-1);
				writer_write(hWriter, ptxaeAttrPtr->szAttrValue, strlen(ptxaeAttrPtr->szAttrValue));
				writer_write(hWriter, "\"", sizeof("\"")-1);
				ptxaeAttrPtr = ptxaeAttrPtr->pNext;
			}while(ptxaeAttrPtr);
		}		
		writer_write(hWriter, ">", sizeof(">")-1);
	}
	// put the element name into stack
	strcpy(pThis->szStack[pThis->dwStackTop], ptxeEle->szElemName);
//	printf("%s:%d %s\n", __FILE__, __LINE__, pThis->szStack[pThis->dwStackTop]);
	pThis->dwStackTop++;
	// child first, sibling next
	if (ptxeEle->pChild != NULL)
	{
		// assume there is no data in the node that has child node
		writer_write(hWriter, "\n", sizeof("\n")-1);
		pThis->iDepth++;
		XmlMgr_Dump(pThis, ptxeEle->pChild, hWriter);
	}
	else
	{
		writer_write(hWriter, ptxeEle->szElemValue, strlen(ptxeEle->szElemValue));
		//DBPRINT0("%s", ptxeEle->szElemValue);
	}
	// pop element name from stack
	pThis->dwStackTop--;
	if (ptxeEle->pChild != NULL)
	{
		for (i=0; i<pThis->iDepth; i++)
		{
			writer_write(hWriter, "\t", sizeof("\t")-1);
		}
	}
	writer_write(hWriter, "</", sizeof("</")-1);
	writer_write(hWriter, pThis->szStack[pThis->dwStackTop], strlen(pThis->szStack[pThis->dwStackTop]));
	writer_write(hWriter, ">\n", sizeof(">\n")-1);
	
	memset(pThis->szStack[pThis->dwStackTop], 0, NAME_SIZE);
	pThis->iDepth--;
	// deal with sibling
	if (ptxeEle->pSibling != NULL)
	{
		pThis->iDepth++;
		XmlMgr_Dump(pThis, ptxeEle->pSibling, hWriter);
	}

	return S_OK;
}

SCODE XmlMgr_WriteFile(HANDLE hObject, const char *szFileName)
{
	int				i;
	TXMLMgrInfo		*pThis = (TXMLMgrInfo *) hObject;
	HANDLE	hWriter;

	if (writer_init(&hWriter, szFileName) != S_OK)
	{
		DBPRINT1("Open output xml file %s fail\n", szFileName);
		return S_FAIL;
	}
	pThis->szStack = malloc(sizeof(char *) * pThis->dwEleNum);
	for (i=0; i<pThis->dwEleNum; i++)
	{
		pThis->szStack[i] = malloc(sizeof(char) * NAME_SIZE);
	}

	// write header
	//writer_write(hWriter, "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>\n", sizeof("<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>\n")-1);
	{
		int iDecaLen = strlen(pThis->szXmlDeca);
		if (iDecaLen > 0)
		{
			writer_write(hWriter, pThis->szXmlDeca, iDecaLen);
			writer_write(hWriter, "\n", 1);
		}
	}
	pThis->iDepth = 0;
	XmlMgr_Dump(pThis, pThis->ptxeRoot->pChild, hWriter);
	writer_rls(&hWriter);

	// check : stack size should be zero
	// DBPRINT0("test : %d\n", pThis->dwStackSize);
	for (i=0; i<pThis->dwEleNum; i++)
	{
		free(pThis->szStack[i]);
	}
	free(pThis->szStack);

	return S_OK;
}

SCODE XmlMgr_GetMultiConfValue(HANDLE hObject, TXmlMgrParsingMap *ptParsingMap)
{
	CHAR	*szConfValue;

	while (ptParsingMap->szName != NULL)
	{
		if ((szConfValue = XmlMgr_GetConfValue(hObject, ptParsingMap->szName)) != NULL)
		{
			ptParsingMap->pfnParsingAction (szConfValue, ptParsingMap->pObject);
		}
		ptParsingMap++;
	}
	return S_OK;
}

SCODE XmlMgr_GetConfMaxMinValue(HANDLE hObject, const char *szConfName, LONG *ret, int op)
{
	char *p;
	char szTmpName[NAME_SIZE];
	char szConfNameSuffix[NAME_SIZE];
	TXMLMgrInfo *pThis;

	pThis = (TXMLMgrInfo *) hObject;
	pThis->ptXSDPointer = pThis->ptXSDList;
	strcpy(szTmpName, szConfName);
	p = strtok(szTmpName, "/");
	while (p != NULL)
	{
		strcpy(szConfNameSuffix, p);
		p = strtok(NULL, "/");
	}
	while (pThis->ptXSDPointer != NULL)
	{
		if (! strcmp(pThis->ptXSDPointer->szElemName, szConfName))
		{
			TXSDIntRestricts *ptRestrict;
			if (pThis->ptXSDPointer->pRestrictions == NULL)
			{
				return S_FAIL;
			}
			ptRestrict = pThis->ptXSDPointer->pRestrictions;
			if (op == 0)
			{
				// get minimum restriction
				*ret = ptRestrict->lMin;
			}
			else
			{
				// get maximum restriction
				*ret = ptRestrict->lMax;
			}
		}
	}
	return S_FAIL;
}

static char* XmlMgr_GetConfValueNoAttr(HANDLE hObject, const char *szConfName)
{	
	char *p;
	char *szTmpName;
	char szTmpConfName[NAME_SIZE];
	TXMLMgrInfo *pThis;

	DBPRINT3("%s:%d %s\n", __FILE__, __func__, szConfName)
	pThis = (TXMLMgrInfo *) hObject;
	pThis->ptxePointer = pThis->ptxeRoot;

	szTmpName = strdup(szConfName);
	if (szTmpName == NULL)
	{
		return NULL;
	}

	// get root
	p = strtok(szTmpName, "/");
	pThis->ptxePointer = pThis->ptxePointer->pChild;
	if (strcmp(pThis->ptxePointer->szElemName, p))
	{
		fprintf(stderr, "%s:%d %s mismatch!\n", __FILE__, __LINE__, szConfName);
		free(szTmpName);
		return NULL;
	}	
	p = strtok(NULL, "/");
	while (p != NULL)
	{
		pThis->ptxePointer = pThis->ptxePointer->pChild;
		if (pThis->ptxePointer == NULL)
		{
			fprintf(stderr, "%s:%d %s mismatch!\n", __FILE__, __LINE__, szConfName);
			free(szTmpName);
			return NULL;
		}
		// find sibling
		while (pThis->ptxePointer != NULL)
		{
			if (strcmp(pThis->ptxePointer->szElemName, p) == 0)
			{
				strcpy(szTmpConfName, p);
				break;
			}
			pThis->ptxePointer = pThis->ptxePointer->pSibling;
		}
		if (pThis->ptxePointer == NULL)
		{
			fprintf(stderr, "%s:%d %s mismatch!\n", __FILE__, __LINE__, szConfName);
			free(szTmpName);
			return NULL;
		}
		p = strtok(NULL, "/");
	}
	if (strcmp(pThis->ptxePointer->szElemName, szTmpConfName) == 0)
	{
//		printf("%s:%d %s\n", __FILE__, __LINE__, szTmpConfName);
		free(szTmpName);
		return pThis->ptxePointer->szElemValue;
	}

	fprintf(stderr, "%s:%d %s mismatch!\n", __FILE__, __LINE__, szConfName);
	free(szTmpName);
	return NULL;
}

/* Get ConfValue by Attribute in start element */
static HANDLE XmlMgr_GetConfValuebyAttr(HANDLE hObject, const char *szConfName)
{	
	DWORD  dwLen;
	char *p;
	TXMLMgrInfo *pThis;	
	char *szTmpName;
	char szTmpConfName[NAME_SIZE];	

	/* attr var */	
	CHAR *pcTmp;
	CHAR szAttrTmp[NAME_SIZE];		
	CHAR *pcTmpAttrName;			//attr name
	CHAR *pcTmpAttrValue;			//attr value
	CHAR *pcNodeName;
	BOOL bAttrFound	= TRUE;	
	TXMLAttrElem *ptxaeAttrPtr, *ptxaeAttrNext;

	DBPRINT3("%s:%d GetConfAttr %s\n", __FILE__, __LINE__, szConfName)
	pThis = (TXMLMgrInfo *) hObject;
	pThis->ptxePointer = pThis->ptxeRoot;
	
	//special need for attribute
	dwLen = strlen(szConfName)+2;
	szTmpName = (CHAR*) malloc(dwLen);
	memset(szTmpName, 0, dwLen);
	strcpy(szTmpName, szConfName);

	// get root
	p = strtok(szTmpName, "/");
	pThis->ptxePointer = pThis->ptxePointer->pChild;
	if (strcmp(pThis->ptxePointer->szElemName, p))
	{
		fprintf(stderr, "%s:%d %s mismatch!\n", __FILE__, __LINE__, szConfName);
		free(szTmpName);
		return NULL;
	}	
	p = strtok(NULL, "/");
	
	while (p != NULL)
	{
		pThis->ptxePointer = pThis->ptxePointer->pChild;
		//attribute is not specified
		if (strchr(p, '@') == NULL)
		{
			//find sibling
			while (pThis->ptxePointer != NULL)
			{
				if (strcmp(pThis->ptxePointer->szElemName, p) == 0)
				{
					memset(szTmpConfName, 0, NAME_SIZE);
					strcpy(szTmpConfName, p);
					break;
				}
				pThis->ptxePointer = pThis->ptxePointer->pSibling;
			}//while sibling
		}
		//find attribute
		else 
		{
			//find sibling
			while (pThis->ptxePointer != NULL)
			{
				if(pThis->ptxePointer->ptAttrElemList)
				{
					//copy attr to new string
					memset(szAttrTmp, 0, NAME_SIZE);
					strcpy(szAttrTmp, p);
					DBPRINT3("%s:%d find %s\n", __FILE__, __LINE__, szAttrTmp)
					
					//new path string to be parsed
					pcTmp = p + strlen(p) -1;
					pcNodeName = strtok(szAttrTmp, " [");				
					if (strcmp(pThis->ptxePointer->szElemName, pcNodeName) == 0)
					{										
						pcTmpAttrName = strtok(NULL, " @=");
						ptxaeAttrNext = pThis->ptxePointer->ptAttrElemList;
						// Attrbute name must arranged in order as conf
						do
						{
							pcTmpAttrValue = strtok(NULL, " ']");
							bAttrFound = FALSE;
							DBPRINT4("%s:%d start to find %s=%s\n", __FILE__, __LINE__, pcTmpAttrName, pcTmpAttrValue)
							while(ptxaeAttrNext)
							{
								// Find pcTmpAttrName = pcTmpAttrValue in current node
								ptxaeAttrPtr = ptxaeAttrNext;
								ptxaeAttrNext = ptxaeAttrPtr->pNext;
								if (strcmp(ptxaeAttrPtr->szAttrName, pcTmpAttrName) == 0)
								{
									if (strcmp(ptxaeAttrPtr->szAttrValue, pcTmpAttrValue) == 0)
									{
										bAttrFound = TRUE;
									}
									break;
								}
							}// while attr node list
							if (! bAttrFound)
							{
								break;
							}
							pcTmpAttrName = strtok(NULL, " =]");
							//if specify attrnum > attrnum in ndoe , show err
							if (!ptxaeAttrNext && pcTmpAttrName)
							{					
								fprintf(stderr, "%s:%d <%s> specified attribute number exceed!!\n", __FILE__, __LINE__, pcNodeName);
								free(szTmpName);
								return NULL;
							}
						}while(pcTmpAttrName);

						//if specified attribute is less than attrnum in node, show err
						if (bAttrFound && !ptxaeAttrNext)
						{						
							strcpy(szTmpConfName, pcNodeName);
							//restart strtok string parsing, "f/" used to be fake parsed once
							pcTmp[0] = 'f';
							pcTmp[1] = '/';
							p = strtok(pcTmp, "/");
							DBPRINT3("%s:%d start Newstr %s!!\n", __FILE__, __LINE__, p)
							break;
						}
					}// match startElem
				}//if ptAttrElemList
				pThis->ptxePointer = pThis->ptxePointer->pSibling;
			}//while sibling
		}//else with attribute
		if (pThis->ptxePointer == NULL)
		{
			fprintf(stderr, "%s:%d %s mismatch!\n", __FILE__, __LINE__, szConfName);
			free(szTmpName);
			return NULL;
		}
		p = strtok(NULL, "/");		
	}//while path	
	if ((!strcmp(pThis->ptxePointer->szElemName, szTmpConfName)) && bAttrFound)
	{		
		free(szTmpName);
		return pThis->ptxePointer;
	}

	fprintf(stderr, "%s:%d %s mismatch!\n", __FILE__, __LINE__, szConfName);
	free(szTmpName);
	return NULL;
}//XmlMgr_GetConfValuebyAttr

char* XmlMgr_GetConfValue(HANDLE hObject, const char *szConfName)
{			
	/*if there doesn't exit attr, call GetConfNoAttr*/
	if (! strchr(szConfName, '@'))
	{		
		return XmlMgr_GetConfValueNoAttr(hObject, szConfName);
	}
	/*if there exits attr, call GetConfbyAttr*/
	else
	{
		TXMLElem *ptxeNode;		
		ptxeNode = XmlMgr_GetConfValuebyAttr(hObject, szConfName);
		if (ptxeNode)
		{
			DBPRINT3("%s:%d %s\n", __FILE__, __LINE__, ptxeNode->szElemValue)
			return ptxeNode->szElemValue;
		}
		return NULL;		
	}
}

SCODE XmlMgr_SetConfValueNoAttr(HANDLE hObject, const char *szConfName, const char *szConfValue)
{
	char		*p;
	char		*szTmpName;
	char		szTmpConfName[NAME_SIZE];
	TXMLMgrInfo	*pThis;
	SCODE		sRet=S_FAIL;

	pThis = (TXMLMgrInfo *) hObject;
	pThis->ptxePointer = pThis->ptxeRoot;

	szTmpName = strdup(szConfName);
	if (szTmpName == NULL)
	{
		return S_FAIL;
	}

	// get root
	p = strtok(szTmpName, "/");
	pThis->ptxePointer = pThis->ptxePointer->pChild;
	if (strcmp(pThis->ptxePointer->szElemName, p))
	{
		goto exit_func;
	}
	p = strtok(NULL, "/");
	while (p != NULL)
	{
		if ((pThis->ptxePointer = pThis->ptxePointer->pChild) == NULL)
		{
			return S_FAIL;
		}
		while (pThis->ptxePointer != NULL)
		{
			if (strcmp(pThis->ptxePointer->szElemName, p) == 0)
			{
				strcpy(szTmpConfName, p);
				break;
			}
			pThis->ptxePointer = pThis->ptxePointer->pSibling;
		}
		if (pThis->ptxePointer == NULL)
		{
			goto exit_func;
		}
		p = strtok(NULL, "/");
	}
	if (strcmp(pThis->ptxePointer->szElemName, szTmpConfName) == 0)
	{
		pThis->ptxePointer->bFirstIn = TRUE;
		sRet = XmlMgr_Elem_SetValue(pThis->ptxePointer, szConfValue, strlen(szConfValue));
	}

exit_func:
	free(szTmpName);
	return sRet;
}//XmlMgr_SetConfValueNoAttr

SCODE XmlMgr_SetConfValue(HANDLE hObject, const char *szConfName, const char *szConfValue)
{	
	TXMLElem *ptxeNode;

	if (strchr(szConfName, '@') == NULL)
	{
		return XmlMgr_SetConfValueNoAttr(hObject, szConfName, szConfValue);
	}
	else
	{
		ptxeNode = XmlMgr_GetConfValuebyAttr(hObject, szConfName);
		if (ptxeNode)
		{
			ptxeNode->bFirstIn = TRUE;
			return XmlMgr_Elem_SetValue(ptxeNode, szConfValue, strlen(szConfValue));
		}		
		return S_FAIL;		
	}
}//XmlMgr_SetConfValue

SCODE XmlMgr_SetMultiConfValue(HANDLE hObject, int iConfNum, const char **szConfNames, const char **szConfValues)
{
	int i;
	// TODO : a more efficient method
	for (i=0; i<iConfNum; i++)
	{
		if (szConfNames[i] && szConfValues[i])
		{
			// printf("%s %d : :%s: :%s:\n", __FILE__, __LINE__, szConfNames[i], szConfValues[i]);
			if (XmlMgr_SetConfValue(hObject, szConfNames[i], szConfValues[i]) != S_OK)
			{
				return S_FAIL;
			}
		}
	}

	return S_OK;
}

SCODE XmlMgr_Reset(HANDLE hObject)
{
	TXMLMgrInfo *pThis;

	pThis = (TXMLMgrInfo *) hObject;

	XML_ParserReset(pThis->xpParser, NULL);
    XML_SetUserData(pThis->xpParser, pThis);
	pThis->ptxePointer = pThis->ptxeRoot->pChild;
	// set all nodes invalid
	if (pThis->ptxePointer != NULL)
	{
		if (XmlMgr_ApplyOpToTreeNode(pThis->ptxePointer, extnoReset) != S_OK)
		{
			return S_FAIL;
		}
	}
	// reset pointer back to root
	pThis->ptxePointer = pThis->ptxeRoot;
    XML_SetElementHandler(pThis->xpParser, XmlMgr_StartElementHandler, XmlMgr_EndElementHandler);
    XML_SetCharacterDataHandler(pThis->xpParser, XmlMgr_CharacterDataHandler);
	// reset XSD
#if 0
	XmlMgr_ResetXSD(pThis);
#endif

	return S_OK;
}

// 2010/05/25 added by djhow
TXMLElem *XmlMgr_NewElem(void)
{
	TXMLElem *ptElem=NULL;

	if ((ptElem = (TXMLElem *)calloc(1, sizeof(TXMLElem))) == NULL)
	{
		goto error_handle;
	}
	ptElem->dwElemValueBufSz	= LEAST_VALUE_SIZE;
	if ((ptElem->szElemValue = (CHAR *)calloc(1, ptElem->dwElemValueBufSz)) == NULL)
	{
		goto error_handle;
	}
	return ptElem;
error_handle:
	XmlMgr_FreeElem(ptElem);
	return NULL;
}

void XmlMgr_FreeElem(TXMLElem *ptElem)
{
	if (ptElem != NULL)
	{
		if (ptElem->szElemValue != NULL)
		{
			free(ptElem->szElemValue);
		}
		free(ptElem);
	}
}

SCODE XmlMgr_Elem_SetValue(TXMLElem *ptElem, const CHAR *szValue, int iValueLen)
{
	if (ptElem->bFirstIn == TRUE)
	{
		if (ptElem->dwElemValueBufSz < iValueLen+1)
		{
			CHAR	*szNewValue;

			if ((szNewValue = (CHAR *)calloc(iValueLen+1, sizeof(CHAR))) == NULL)
			{
				return S_FAIL;
			}
			free(ptElem->szElemValue);
			ptElem->szElemValue			= szNewValue;
			ptElem->dwElemValueBufSz	= iValueLen+1;
		}
		strncpy(ptElem->szElemValue, szValue, iValueLen);
		ptElem->szElemValue[iValueLen] = '\0';
		ptElem->bFirstIn = FALSE;
	}
	else
	{
		int	iOrigStrLen	= strlen(ptElem->szElemValue);
		int	iNewStrLen	= iOrigStrLen+iValueLen;

		if (ptElem->dwElemValueBufSz < iNewStrLen+1)
		{
			CHAR	*szNewValue;

			if ((szNewValue = (CHAR *)calloc(iNewStrLen+1, sizeof(CHAR))) == NULL)
			{
				return S_FAIL;
			}
			strcpy(szNewValue, ptElem->szElemValue);
			free(ptElem->szElemValue);
			ptElem->szElemValue			= szNewValue;
			ptElem->dwElemValueBufSz	= iNewStrLen+1;
		}
		strncpy(ptElem->szElemValue+iOrigStrLen, szValue, iValueLen);
		ptElem->szElemValue[iNewStrLen] = '\0';
		//ptElem->bFistIn = FALSE;
	}
	return S_OK;
}
