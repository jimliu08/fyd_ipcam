/*
 *******************************************************************************
 * $Header: $
 *
 *  Copyright (c) 2011-2015 VN Inc. All rights reserved.
 *
 *  +-----------------------------------------------------------------+
 *  | THIS SOFTWARE IS FURNISHED UNDER A LICENSE AND MAY ONLY BE USED |
 *  | AND COPIED IN ACCORDANCE WITH THE TERMS AND CONDITIONS OF SUCH  |
 *  | A LICENSE AND WITH THE INCLUSION OF THE THIS COPY RIGHT NOTICE. |
 *  | THIS SOFTWARE OR ANY OTHER COPIES OF THIS SOFTWARE MAY NOT BE   |
 *  | PROVIDED OR OTHERWISE MADE AVAILABLE TO ANY OTHER PERSON. THE   |
 *  | OWNERSHIP AND TITLE OF THIS SOFTWARE IS NOT TRANSFERRED.        |
 *  |                                                                 |
 *  | THE INFORMATION IN THIS SOFTWARE IS SUBJECT TO CHANGE WITHOUT   |
 *  | ANY PRIOR NOTICE AND SHOULD NOT BE CONSTRUED AS A COMMITMENT BY |
 *  | VN INC.                                                     |
 *  +-----------------------------------------------------------------+
 *
 * $History: $
 * 
 *******************************************************************************
 */

/*!
 *******************************************************************************
 * Copyright 2011-2015 VN, Inc. All rights reserved.
 *
 * \file xmlmgr_writer.c
 *
 * \brief
 *
 * \date 2011-09-15
 *
 * \author djhow.tu@VN.com
 *
 *******************************************************************************
 */
#include "xmlmgr_writer.h"
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>

typedef struct writer
{
	char	*pcBuf;
	int		iBufSz;
	int		iBufUsedSz;
	int		iFd;
} TWriter;

SCODE writer_init(HANDLE *phWriter, const char *szFileName)
{
	TWriter	*pThis;

	if (szFileName == NULL)
	{
		return S_FAIL;
	}
	pThis = (TWriter *)calloc(1, sizeof(TWriter));
	if (pThis == NULL)
	{
		return S_FAIL;
	}
	*phWriter = pThis;
	pThis->iFd = -1;

	pThis->iBufSz	= 1024;
	pThis->pcBuf	= (char *)calloc(1, pThis->iBufSz);
	if (pThis->pcBuf == NULL)
	{
		goto error_handle;
	}

	pThis->iFd = open(szFileName, O_WRONLY | O_SYNC | O_CREAT | O_TRUNC, S_IRWXU);
	if (pThis->iFd < 0)
	{
		goto error_handle;
	}

	{
		struct flock	tFLock;
		memset(&tFLock, 0, sizeof(struct flock));
		tFLock.l_type	= F_WRLCK;
		tFLock.l_whence	= SEEK_SET;
		tFLock.l_start	= 0;
		tFLock.l_len	= 0;

		while (fcntl(pThis->iFd, F_SETLKW, &tFLock) == -1)
		{
			if (errno != EINTR)
			{
				goto error_handle;
			}
		}
	}
	return S_OK;
error_handle:
	writer_rls(phWriter);
	return S_FAIL;
}

SCODE writer_write(HANDLE hWriter, const void *buf, size_t count)
{
	TWriter	*pThis=(TWriter *)hWriter;
	int		iFreeSpace;
	int		iUnfinishedSz=count;

	while (iUnfinishedSz > 0)
	{
		iFreeSpace = pThis->iBufSz - pThis->iBufUsedSz;
		if (iFreeSpace >= iUnfinishedSz)
		{
			memcpy(pThis->pcBuf+pThis->iBufUsedSz, buf+(count-iUnfinishedSz), iUnfinishedSz);
			pThis->iBufUsedSz += iUnfinishedSz;
			iUnfinishedSz = 0;
		}
		else
		{
			memcpy(pThis->pcBuf+pThis->iBufUsedSz, buf+(count-iUnfinishedSz), iFreeSpace);
			pThis->iBufUsedSz += iFreeSpace;
			iUnfinishedSz -= iFreeSpace;
		}
		if (pThis->iBufUsedSz == pThis->iBufSz)
		{
			int iRet;
			iRet = write(pThis->iFd, pThis->pcBuf, pThis->iBufSz);
			pThis->iBufUsedSz = 0;
		}
	}
	return S_OK;
}

SCODE writer_flush(HANDLE hWriter)
{
	TWriter	*pThis=(TWriter *)hWriter;

	if (pThis->iBufUsedSz > 0)
	{
		int iRet;
		iRet = write(pThis->iFd, pThis->pcBuf, pThis->iBufUsedSz);
		pThis->iBufUsedSz = 0;
	}
	return S_OK;
}

SCODE writer_rls(HANDLE *phWriter)
{
	TWriter	*pThis;

	if (!phWriter || !(*phWriter))
	{
		return S_FAIL;
	}
	pThis = *phWriter;

	if (pThis->iFd >= 0)
	{
		struct flock	tFLock;

		writer_flush(pThis);

		memset(&tFLock, 0, sizeof(struct flock));
		tFLock.l_type	= F_UNLCK;
		tFLock.l_whence	= SEEK_SET;
		tFLock.l_start	= 0;
		tFLock.l_len	= 0;
		fcntl(pThis->iFd, F_SETLK, &tFLock);
		
		close(pThis->iFd);
	}
	if (pThis->pcBuf != NULL)
	{
		free(pThis->pcBuf);
	}
	free(pThis);
	*phWriter = NULL;
	return S_OK;
}
