/*
 *******************************************************************************
 * $Header: $
 *
 *  Copyright (c) 2000-2006 VN Inc. All rights reserved.
 *
 *  +-----------------------------------------------------------------+
 *  | THIS SOFTWARE IS FURNISHED UNDER A LICENSE AND MAY ONLY BE USED |
 *  | AND COPIED IN ACCORDANCE WITH THE TERMS AND CONDITIONS OF SUCH  |
 *  | A LICENSE AND WITH THE INCLUSION OF THE THIS COPY RIGHT NOTICE. |
 *  | THIS SOFTWARE OR ANY OTHER COPIES OF THIS SOFTWARE MAY NOT BE   |
 *  | PROVIDED OR OTHERWISE MADE AVAILABLE TO ANY OTHER PERSON. THE   |
 *  | OWNERSHIP AND TITLE OF THIS SOFTWARE IS NOT TRANSFERRED.        |
 *  |                                                                 |
 *  | THE INFORMATION IN THIS SOFTWARE IS SUBJECT TO CHANGE WITHOUT   |
 *  | ANY PRIOR NOTICE AND SHOULD NOT BE CONSTRUED AS A COMMITMENT BY |
 *  | VN INC.                                                    |
 *  +-----------------------------------------------------------------+
 *
 * $History: $
 * 
 *******************************************************************************
 */

/*!
 *******************************************************************************
 * Copyright 2000-2006 VN, Inc. All rights reserved.
 *
 * \file
 * xmlmgr_xsd.c
 *
 * \brief
 * XML configuration file parsing (read/write) library - XSD (XML Schema Definition) expat handler
 *
 * \date
 * 2006/11/02
 *
 * \author
 * Rey Cheng
 *
 *
 *******************************************************************************
 */

#if 0

#include <stdio.h>
#include <string.h>
#include "xmlmgr_xsd.h"

#define BUFFSIZE        8192

void XSD_StartElementHandler(void *userData, const char *el, const char **attr)
{
	int i;
	TXMLMgrInfo *pThis;

	pThis = (TXMLMgrInfo *) userData;
	if (! strcmp(el, "xs:element"))
	{
		for (i = 0; attr[i]; i += 2)
		{
			if (! strcmp(attr[i], "name"))
			{
				strcpy (pThis->ptXSDPointer->szElemName, attr[i+1]);
			}
		}
	}
	else if (! strcmp(el, "xs:complexType"))
	{
		pThis->ptXSDPointer->exntNodeType = exntComplex;
	}
	else if (! strcmp(el, "xs:restriction"))
	{
		for (i = 0; attr[i]; i += 2)
		{
			if (! strcmp(attr[i], "base"))
			{
				if (! strcmp(attr[i+1], "xs:integer"))
				{
					pThis->ptXSDPointer->exntNodeType = exntInteger;
				}
				else if (! strcmp(attr[i+1], "xs:string"))
				{
					pThis->ptXSDPointer->exntNodeType = exntString;
				}
			}
		}
	}
	else if ((! strcmp(el, "xs:minInclusive")) || (! strcmp(el, "xs:maxInclusive")))
	{
		if (pThis->ptXSDPointer->exntNodeType != exntInteger)
		{
			DBPRINT0("XSD file parsing fail\n");
			exit(1);
		}
		if (pThis->ptXSDPointer->pRestrictions == NULL)
		{
			if (pThis->ptXSDPointer->pRestrictions == NULL)
			{
				pThis->ptXSDPointer->pRestrictions = malloc(sizeof(TXSDIntRestricts));
			}
		}
		for (i = 0; attr[i]; i += 2)
		{
			if (! strcmp(attr[i], "value"))
			{
				TXSDIntRestricts *ptIntRestrict;
				ptIntRestrict = pThis->ptXSDPointer->pRestrictions;
				if (! strcmp(el, "xs:minInclusive"))
				{
					ptIntRestrict->lMin = atoi(attr[i+1]);
				}
				else
				{
					ptIntRestrict->lMax = atoi(attr[i+1]);
				}
			}
		}
	}

	return;
}

void XSD_EndElementHandler(void *userData, const char *el)
{
	TXMLMgrInfo *pThis;

	pThis = (TXMLMgrInfo *) userData;
	if (! strcmp(el, "xs:element"))
	{
		if (pThis->ptXSDPointer->pNext == NULL)
		{
			pThis->ptXSDPointer->pNext = malloc(sizeof(TXSDListNode));
			memset(pThis->ptXSDPointer->pNext, 0, sizeof(TXSDListNode));
		}
		pThis->ptXSDPointer = pThis->ptXSDPointer->pNext;
	}

	return;
}

void XSD_CharacterDataHandler(void *userData, const XML_Char *s, int len)
{
	return;
}

SCODE XmlMgr_ApplyOpToXSDNode(TXSDListNode *pXSDNode, EXMLTreeNodeOp extnoOp)
{
	// if next exists
	if (pXSDNode->pNext)
	{
		XmlMgr_ApplyOpToXSDNode(pXSDNode->pNext, extnoOp);
	}
	if (extnoOp == extnoFree)
	{
		free (pXSDNode);
		pXSDNode = NULL;
	}
	else if (extnoOp == extnoReset)
	{
		memset(pXSDNode->szElemName, 0, sizeof(pXSDNode->szElemName));
//printf("xmlmgr xsd reset %s\n", pXSDNode->szElemName);
	}
	return S_OK;
}

SCODE XmlMgr_ResetXSD(TXMLMgrInfo *pThis)
{
	// set all nodes invalid
	if (pThis->ptXSDList != NULL)
	{
		if (XmlMgr_ApplyOpToXSDNode(pThis->ptXSDList, extnoReset) != S_OK)
		{
			return S_FAIL;
		}
	}
	// reset pointer back to root
	pThis->ptXSDPointer = pThis->ptXSDList;

	return S_OK;
}

SCODE XmlMgr_ReleaseXSD(TXMLMgrInfo *pThis)
{
	pThis->ptXSDPointer = pThis->ptXSDList;
	if (pThis->ptXSDPointer != NULL)
	{
		if (XmlMgr_ApplyOpToXSDNode(pThis->ptXSDPointer, extnoFree) != S_OK)
		{
			return S_FAIL;
		}
	}

	return S_OK;
}

SCODE XmlMgr_ParsingXSD(TXMLMgrInfo *pThis, FILE *fpXSDSrc)
{
	int iLength, iDone;
	char acBuf[BUFFSIZE];
	XML_Parser xpXSDParser;

	if ((xpXSDParser = XML_ParserCreate(NULL)) == NULL)
	{
		DBPRINT0("Couldn't allocate memory for XSD parser\n");
		return ERR_OUT_OF_MEMORY;
	}
	// set current xsd pointer to root
	if (pThis->ptXSDList == NULL)
	{
		pThis->ptXSDList = malloc(sizeof(TXSDListNode));
		memset(pThis->ptXSDList, 0, sizeof(TXSDListNode));
	}
	pThis->ptXSDPointer = pThis->ptXSDList;
	// set user data
	XML_SetUserData(xpXSDParser, pThis);
	/* set element handler */
	XML_SetElementHandler(xpXSDParser, XSD_StartElementHandler, XSD_EndElementHandler);
	/* set char data handler */
	XML_SetCharacterDataHandler(xpXSDParser, XSD_CharacterDataHandler);
	for (; ; )
	{
		iLength = fread(acBuf, 1, BUFFSIZE, fpXSDSrc);
		iDone = feof(fpXSDSrc);

		if (XML_Parse(xpXSDParser, acBuf, iLength, iDone) == XML_STATUS_ERROR)
		{
			fprintf(stderr, "Parse error at line %d:\n%s\n", 
						XML_GetCurrentLineNumber(xpXSDParser), XML_ErrorString(XML_GetErrorCode(xpXSDParser)));
			return S_FAIL;
		}

		if (iDone)
		{
			break;
		}
	}
	XML_ParserFree(xpXSDParser);

	return S_OK;
}

#endif
