/*
 *******************************************************************************
 * $Header: $
 *
 *  Copyright (c) 2000-2006 VN Inc. All rights reserved.
 *
 *  +-----------------------------------------------------------------+
 *  | THIS SOFTWARE IS FURNISHED UNDER A LICENSE AND MAY ONLY BE USED |
 *  | AND COPIED IN ACCORDANCE WITH THE TERMS AND CONDITIONS OF SUCH  |
 *  | A LICENSE AND WITH THE INCLUSION OF THE THIS COPY RIGHT NOTICE. |
 *  | THIS SOFTWARE OR ANY OTHER COPIES OF THIS SOFTWARE MAY NOT BE   |
 *  | PROVIDED OR OTHERWISE MADE AVAILABLE TO ANY OTHER PERSON. THE   |
 *  | OWNERSHIP AND TITLE OF THIS SOFTWARE IS NOT TRANSFERRED.        |
 *  |                                                                 |
 *  | THE INFORMATION IN THIS SOFTWARE IS SUBJECT TO CHANGE WITHOUT   |
 *  | ANY PRIOR NOTICE AND SHOULD NOT BE CONSTRUED AS A COMMITMENT BY |
 *  | VN INC.                                                    |
 *  +-----------------------------------------------------------------+
 *
 * $History: $
 * 
 *******************************************************************************
 */

/*!
 *******************************************************************************
 * Copyright 2000-2006 VN, Inc. All rights reserved.
 *
 * \file
 * xmlmgr_handler.c
 *
 * \brief
 * XML configuration file parsing (read/write) library - handlers for the expat parser
 *
 * \date
 * 2006/08/24
 *
 * \author
 * Rey Cheng
 *
 *
 *******************************************************************************
 */

#include <stdio.h>
#include <string.h>
#include "xmlmgr_handler.h"
#include "xmlmgr_xsd.h"

void XmlMgr_StartElementHandler(void *userData, const char *el, const char **attr)
{
	int i;
	TXMLMgrInfo *pThis = (TXMLMgrInfo *) userData;	

	// find invalid child, and fill it
	if (pThis->ptxePointer->pChild == NULL || strlen(pThis->ptxePointer->pChild->szElemName) == 0)
	{
		if (pThis->ptxePointer->pChild == NULL)
		{
			// 2010/05/25 modified by djhow
			//if ((pThis->ptxePointer->pChild = malloc(sizeof(TXMLElem))) == NULL)
			if ((pThis->ptxePointer->pChild = XmlMgr_NewElem()) == NULL)
			{
				DBPRINT2("Out of memory : %d at %s\n", __LINE__, __FILE__);
				return;
			}
			//memset(pThis->ptxePointer->pChild, 0, sizeof(TXMLElem));
			DBPRINT0("(malloc) ");
			pThis->ptxePointer->pChild->pParent = pThis->ptxePointer;
		}
		pThis->ptxePointer = pThis->ptxePointer->pChild;
		DBPRINT1("add child %p : ", pThis->ptxePointer);
	}
	else
	{
		TXMLElem *ptxeParent;
		ptxeParent = pThis->ptxePointer;
		pThis->ptxePointer = pThis->ptxePointer->pChild;
		// find invalid sibling
		while (pThis->ptxePointer->pSibling != NULL && strlen(pThis->ptxePointer->pSibling->szElemName) != 0)
		{
			pThis->ptxePointer = pThis->ptxePointer->pSibling;
		}
		if (pThis->ptxePointer->pSibling == NULL)
		{
			// 2010/05/25 modified by djhow
			//if ((pThis->ptxePointer->pSibling = malloc(sizeof(TXMLElem))) == NULL)
			if ((pThis->ptxePointer->pSibling = XmlMgr_NewElem()) == NULL)
			{
				DBPRINT2("Out of memory : %d at %s\n", __LINE__, __FILE__);
				exit(1);
			}
			//memset(pThis->ptxePointer->pSibling, 0, sizeof(TXMLElem));
			pThis->ptxePointer->pSibling->pParent = ptxeParent;
			DBPRINT0("(malloc) ");
		}
		pThis->ptxePointer = pThis->ptxePointer->pSibling;
		DBPRINT2("add sibling %p (parent %p) : ", pThis->ptxePointer, ptxeParent);
	}

	strcpy(pThis->ptxePointer->szElemName, el);
	pThis->ptxePointer->bFirstIn = TRUE;
	DBPRINT3("%s %d : %s\n", __FILE__, __LINE__, el);

	/* add attribute, added by Erin 2007/04/13 */	
	if (attr[0])
	{		
		TXMLAttrElem **pptxaePreAttrNode = (TXMLAttrElem **) &(pThis->ptxePointer->ptAttrElemList);
		TXMLAttrElem *ptxaeAttrNode = *pptxaePreAttrNode;	
		i = 0;
		do
		{
//			printf("%s:%d %s=%s\n", __FILE__, __LINE__, attr[i], attr[i+1]);
			if (ptxaeAttrNode == NULL)
			{
//				printf("malloc\n");
				ptxaeAttrNode = (TXMLAttrElem *) malloc (sizeof(TXMLAttrElem));
				if (ptxaeAttrNode == NULL)
				{
					fprintf(stderr, "malloc no space!!\n");
					exit(1);
				}
				memset(ptxaeAttrNode, 0, sizeof(TXMLAttrElem));
				*pptxaePreAttrNode = ptxaeAttrNode;
			}		
			memcpy(ptxaeAttrNode->szAttrName, attr[i], strlen(attr[i]));
			memcpy(ptxaeAttrNode->szAttrValue, attr[i+1], strlen(attr[i+1]));
			pptxaePreAttrNode = &(ptxaeAttrNode->pNext);
			ptxaeAttrNode = *pptxaePreAttrNode;		
			i += 2;
		}while(attr[i]);
	}//if attribute	

#if 0
	// check if xml schema
	for (i = 0; attr[i]; i += 2)
	{
		// support noNamespaceSchemaLocation only
		if (! strcmp(attr[i], "xsi:noNamespaceSchemaLocation"))
		{
			FILE *fpXSDSrc;
			strcpy(pThis->szXSDSrc, attr[i+1]);
			if ((fpXSDSrc = fopen(pThis->szXSDSrc, "r")) == NULL)
			{
				DBPRINT3("%s %d : Open XML %s\n", __FILE__, __LINE__, pThis->szXSDSrc);
				exit(1);
			}
			// create XSD tree
			XmlMgr_ParsingXSD(pThis, fpXSDSrc);
			fclose(fpXSDSrc);
		}
	}
#endif

	return;
}

void XmlMgr_EndElementHandler(void *userData, const char *el)
{
	TXMLMgrInfo *pThis;

	pThis = (TXMLMgrInfo *) userData;

	pThis->ptxePointer->bFirstIn = FALSE;
	pThis->ptxePointer = pThis->ptxePointer->pParent;
	pThis->dwEleNum++;
DBPRINT2("back to parent(%s) %p\n", el, pThis->ptxePointer);
	return;
}

void XmlMgr_CharacterDataHandler(void *userData, const XML_Char *s, int len)
{
	TXMLMgrInfo *pThis;

	pThis = (TXMLMgrInfo *) userData;
	
	// 2010/05/25 modified by djhow
#if 0
	// 2010/05/18 added by djhow
	if (pThis->ptxePointer->szElemValue != NULL)
	{
		free(pThis->ptxePointer->szElemValue);
	}
	if ((pThis->ptxePointer->szElemValue = (CHAR *)calloc(1, len+1)) == NULL)
	{
		printf("[%s:%s:%d] warning! calloc error!\n", __func__, __FILE__, __LINE__);
		return;
	}
#endif
#if 0
	if (pThis->ptxePointer->dwElemValueBufSz < len+1)
	{
		free(pThis->ptxePointer->szElemValue);
		if ((pThis->ptxePointer->szElemValue = (CHAR *)calloc(len+1, sizeof(CHAR))) != NULL)
		{
			pThis->ptxePointer->dwElemValueBufSz = len+1;
		}
		else
		{
			pThis->ptxePointer->dwElemValueBufSz = 0;
			return;
		}
	}

	snprintf(pThis->ptxePointer->szElemValue, len+1, "%s", s);
	pThis->ptxePointer->szElemValue[len] = '\0';
	DBPRINT3("%s:%d char:%s\n", __FILE__, __LINE__, pThis->ptxePointer->szElemValue)
#endif
	XmlMgr_Elem_SetValue(pThis->ptxePointer, s, len);

	return;
}
