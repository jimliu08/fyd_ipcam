/*
 *******************************************************************************
 * $Header: $
 *
 *  Copyright (c) 2011-2015 VN Inc. All rights reserved.
 *
 *  +-----------------------------------------------------------------+
 *  | THIS SOFTWARE IS FURNISHED UNDER A LICENSE AND MAY ONLY BE USED |
 *  | AND COPIED IN ACCORDANCE WITH THE TERMS AND CONDITIONS OF SUCH  |
 *  | A LICENSE AND WITH THE INCLUSION OF THE THIS COPY RIGHT NOTICE. |
 *  | THIS SOFTWARE OR ANY OTHER COPIES OF THIS SOFTWARE MAY NOT BE   |
 *  | PROVIDED OR OTHERWISE MADE AVAILABLE TO ANY OTHER PERSON. THE   |
 *  | OWNERSHIP AND TITLE OF THIS SOFTWARE IS NOT TRANSFERRED.        |
 *  |                                                                 |
 *  | THE INFORMATION IN THIS SOFTWARE IS SUBJECT TO CHANGE WITHOUT   |
 *  | ANY PRIOR NOTICE AND SHOULD NOT BE CONSTRUED AS A COMMITMENT BY |
 *  | VN INC.                                                     |
 *  +-----------------------------------------------------------------+
 *
 * $History: $
 * 
 *******************************************************************************
 */

/*!
 *******************************************************************************
 * Copyright 2011-2015 VN, Inc. All rights reserved.
 *
 * \file xmlmgr_writer.h
 *
 * \brief
 *
 * \date 2011-09-15
 *
 * \author djhow.tu@VN.com
 *
 *******************************************************************************
 */
#ifndef _XMLMGR_WRITER_H_
#define _XMLMGR_WRITER_H_

#include "typedef.h"
#include "errordef.h"
#include "vivo_codec.h"
#include <unistd.h>

SCODE writer_init(HANDLE *phWriter, const char *szFileName);
SCODE writer_write(HANDLE hWriter, const void *buf, size_t count);
SCODE writer_flush(HANDLE hWriter);
SCODE writer_rls(HANDLE *phWriter);

#endif // _XMLMGR_WRITER_H_
